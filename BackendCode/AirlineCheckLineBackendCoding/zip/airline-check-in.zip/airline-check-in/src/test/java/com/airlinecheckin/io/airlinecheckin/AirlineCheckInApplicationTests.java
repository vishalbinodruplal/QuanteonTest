package com.airlinecheckin.io.airlinecheckin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineCheckInApplicationTests {

	@Test
	void contextLoads() {
	}

}
