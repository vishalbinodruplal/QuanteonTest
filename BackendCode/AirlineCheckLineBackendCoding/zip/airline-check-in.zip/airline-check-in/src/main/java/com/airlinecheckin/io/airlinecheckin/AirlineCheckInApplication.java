package com.airlinecheckin.io.airlinecheckin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineCheckInApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineCheckInApplication.class, args);
	}

}
